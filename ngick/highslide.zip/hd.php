<script type="text/x-mathjax-config">
  MathJax.Hub.Config({tex2jax: {inlineMath: [['$','$'], ['\\(','\\)']]}});
</script>
<script type="text/javascript"
  src="http://cdn.mathjax.org/mathjax/latest/MathJax.js?config=TeX-AMS-MML_HTMLorMML">
</script>


<script type="text/javascript" src="highslide/highslide-with-html.js"></script>
<link rel="stylesheet" type="text/css" href="highslide/highslide.css" />
<script type="text/javascript">
	hs.graphicsDir = 'highslide/graphics/';
	hs.outlineType = 'rounded-white';
	hs.showCredits = false;
	hs.wrapperClassName = 'draggable-header';
</script>


<style>
table.title1
{
width:400px;
margin-left:auto;
margin-right:auto;
}
td.header1
{
text-align:center;
color:blue;
font-style:italic;
font-weight:bold;
font-size:20px;
border-style:solid;
border-width:10px;
border-color:red;
border-bottom:0px solid red; 
}
td.header2
{
text-align:center;
color:blue;
font-style:italic;
font-weight:bold;
font-size:20px;
}
td.footer1
{
text-align:center;
color:blue;
font-style:italic;
font-weight:bold;
font-size:20px;
border-style:solid;
border-width:10px;
border-color:red;
border-bottom:0px solid red; 
border-left:0px solid red;
border-right:0px solid red;
}
table.box1,td.box1
{
width:400px;
border: 1px solid blue;
border-collapse:collapse;
margin-left:auto;
margin-right:auto;
}
th.boxH
{
border:1px solid blue;
text-align:center;
color:blue;
font-style:italic;
padding:10px;
}
td.boxT
{
text-align:justify;
padding:10px;
}
td.boxB
{
width:50%;
border:1px solid blue;
text-align:center;
padding:5px;
}
div.con,tr.con,span.con
{
background: #99ffdd;
}

/*
img {
    max-width: 100%;
    height: auto;
    width: auto\9; /* ie8 */
}
*/

</style>

<?php echo $_SERVER['HTTP_HOST'] ?>
$x \over y$
